package Mixed;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import PageBin.PageFactoryLog;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
private WebDriver driver;
private PageFactoryLog obj;

/*
@Given("^User is on login page\\.$")
public void user_is_on_login_page() throws Throwable {
 
	
}*/
/*
@Then("^enter valid credential\\.$")
public void enter_valid_credential() throws Throwable {
  
}

@When("^navigate to registration page\\.$")
public void navigate_to_registration_page() throws Throwable {
    
	
}

@Given("^User is on registraion page\\.$")
public void user_is_on_registraion_page() throws Throwable {
 
	
	
}

@Then("^User enter all valid data\\.$")
public void user_enter_all_valid_data() throws Throwable {
   
	o

@When("^USer Navigate to welcome page\\.$")
public void user_Navigate_to_welcome_page() throws Throwable {
	
	
}
	
}
*/



@Given("^User is on login page\\.$")
public void user_is_on_login_page() throws Throwable {

	System.setProperty("webdriver.chrome.driver", "D:\\Users\\vikagoya\\Desktop\\Module-3\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	obj = new PageFactoryLog(driver);
	driver.get("file:///D:/Users/VIKAGOYA/Desktop/Module-3/login.html");
}

@Then("^enter invalid credential\\.$")
public void enter_invalid_credential() throws Throwable {
    obj.setUser("vikas0");
    obj.setPass("rasam");
    Thread.sleep(1000);
    obj.setLogin();
    
    
    Thread.sleep(2000);
    driver.close();
}

@When("^Navigate to login page again\\.$")
public void navigate_to_login_page_again() throws Throwable {
	
}

@Then("^enter valid credential\\.$")
public void enter_valid_credential() throws Throwable {
   
	  
		obj.setUser("capgemini");Thread.sleep(1000);
		obj.setPass("capg1234");Thread.sleep(1000);
		obj.setLogin();
		//driver.close();
}

@When("^navigate to registration page\\.$")
public void navigate_to_registration_page() throws Throwable {
   
}

@Given("^User is on registraion page\\.$")
public void user_is_on_registraion_page() throws Throwable {

	System.setProperty("webdriver.chrome.driver", "D:\\Users\\vikagoya\\Desktop\\Module-3\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	obj = new PageFactoryLog(driver);
	driver.get("file://ndafile/GLC-G102/BDD/Selenium/hotelbooking.html");
}

@Then("^User enter all valid data\\.$")
public void user_enter_all_valid_data() throws Throwable {
  
	
	 obj.setPffname("Rutuja");	Thread.sleep(1000);
	obj.setPflname("Kulkarni");	Thread.sleep(1000);
	obj.setPfemail("rutukulkarni2003@yahoo.com");	Thread.sleep(1000);
	obj.setPfmobile("7722005480");	Thread.sleep(1000);
	obj.setPfcity("Pune");	Thread.sleep(1000);
	obj.setPfstate("Maharashtra");	Thread.sleep(1000);
	obj.setPfpersons(5);	Thread.sleep(1000);
	obj.setPfcardholder("Rutuja Kulkarni");	Thread.sleep(1000);
	obj.setPfdebit("5678567867897890");	Thread.sleep(1000);
	obj.setPfcvv("067");	Thread.sleep(1000);
	obj.setPfmonth("5");	Thread.sleep(1000);
	obj.setPfyear("2020"); 
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	obj.setPfbutton();
}
	


@When("^USer Navigate to welcome page\\.$")
public void user_Navigate_to_welcome_page() throws Throwable {
	
	driver.navigate().to("file://ndafile/GLC-G102/BDD/Selenium/success.html");
	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	Thread.sleep(1000);
  
}




}

